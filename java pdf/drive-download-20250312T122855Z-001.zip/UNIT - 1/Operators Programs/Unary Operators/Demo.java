import java.util.*;
public class Demo{
    public static void main(String[] args){
        //Unary Operators
        int a=10;
        //unary plus(+)
        System.out.println(+a);
        //unary plus(-)
        System.out.println(-a);
        //post-increament (++)
        System.out.println(a++);
        //pre-increament (++)
        System.out.println(++a);
        //post-decreament (--)
        System.out.println(a--);
        //pre-decreament (--)
        System.out.println(--a);
        //negation  (~)
        System.out.println(~a);
        //NOT operator (!)
        boolean isFun=false;
        System.out.println(!isFun);
    }
}